import App from "./App";


const routes = [

    {path:'/', component:App,exact:true},
    {path:'/report', component:App}
];

export default routes