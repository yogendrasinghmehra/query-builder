const Report = () => {
  return (
    <div>
      <h1>Report</h1>
    </div>
  )
}

export default Report
